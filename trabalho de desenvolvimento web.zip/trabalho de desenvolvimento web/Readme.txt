desenvolvido pela equipe de ciencia da computa��o TURMA CIN05S1
FABIANO LIMA
JOILTON CABRAL
JOS� IRLAN 
JONAS
crie uma ssh key
Criando chave ssh - https://www.youtube.com/watch?v=cEgOvHJ8IRU

-video aulas - Plataforma Visual Code -
dominando o visual code - https://www.youtube.com/watch?v=Po4d8Q2krcE 
23 extensões do vs code para 2020 que voce precisa ter - https://www.youtube.com/watch?v=tmgpF7Bn3_E
12 dicas rapidas para usar vs code como profissional - https://www.youtube.com/watch?v=ODc-55gm_Mc

o projeto continua...
DESENVOLVIMENTO DO PROJETO NO PLANNER - FINALIZAR TODAS AS TAREFAS